public class Order {
    private Customer customer;
    private MenuItem item1;
    private MenuItem item2;
    private MenuItem item3;
    private int itemCount;
    private String orderId;

    public Order(String orderId, Customer customer) {
        this.orderId = orderId;
        this.customer = customer;
        itemCount = 0;
    }

    public boolean addItem(MenuItem item) {
        if (item == null) {
            return false;
        }

        if (itemCount >= 3) {
            System.out.println("Order is full!");
            return false;
        }

        if (item1 == null) {
            item1 = item;
        } else if (item2 == null) {
            item2 = item;
        } else {
            item3 = item;
        }

        itemCount++;
        return true;
    }

    public double computeSubtotal() {
        double subtotal = 0;

        if (item1 != null) {
            subtotal += item1.computePrice();
        }

        if (item2 != null) {
            subtotal += item2.computePrice();
        }

        if (item3 != null) {
            subtotal += item3.computePrice();
        }

        return subtotal;
    }

    public double computeTotal() {
        double subtotal = computeSubtotal();

        if (customer.isStudent()) {
            subtotal -= subtotal * 0.10;
        }

        return subtotal;
    }

    public double computeTotal(double voucher) {
        double total = computeTotal() - voucher;

        if (total < 0) {
            total = 0;
        }

        return total;
    }

    public void printReceipt() {
        printReceipt(0);
    }

    public void printReceipt(double voucher) {
        System.out.println("\n===== CAMPUS CAFE =====");
        System.out.println("Order ID: " + orderId);
        System.out.println("Customer: " + customer.getName());

        if (item1 != null) {
            System.out.println(item1.getDescription()
                    + " - " + item1.computePrice());
        }

        if (item2 != null) {
            System.out.println(item2.getDescription()
                    + " - " + item2.computePrice());
        }

        if (item3 != null) {
            System.out.println(item3.getDescription()
                    + " - " + item3.computePrice());
        }

        System.out.printf("Subtotal: %.2f%n", computeSubtotal());

        System.out.printf("Total: %.2f%n",
                computeTotal(voucher));

        customer.addPoints(computeTotal(voucher));

        System.out.println("Loyalty Points: "
                + customer.getLoyaltyPoints());

        System.out.println("=======================");
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public int getItemCount() {
        return itemCount;
    }
}
