# Palumar Cafe System

A simple Java console-based Campus Cafe ordering system.

## Files
- `MenuItem.java` - Abstract parent class for menu items.
- `Beverage.java` - Beverage item with size-based pricing.
- `Pastry.java` - Pastry item with optional warming charge.
- `Meal.java` - Meal item with upsizing and extra-side charges.
- `Customer.java` - Customer details, student status, and loyalty points.
- `Order.java` - Order management, pricing, discounts, vouchers, and receipt.
- `CafeApp.java` - Main program demonstrating two sample orders.

## How to run
Make sure all `.java` files are in the same folder. Open a terminal in this folder and run:

```bash
javac *.java
java CafeApp
```
