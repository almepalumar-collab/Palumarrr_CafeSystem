public class CafeApp {
    public static void main(String[] args) {

        Customer customer1 =
                new Customer("Ana Reyes", true);

        Customer customer2 =
                new Customer("Ben Cruz", false);

        Beverage latte =
                new Beverage("Iced Latte", 80,
                        "B-01", "L");

        Pastry ensaymada =
                new Pastry("Ensaymada", 55,
                        "P-01", true);

        Meal chicken =
                new Meal("Chicken Adobo", 110,
                        "M-01", true, 1);

        Beverage chocolate =
                new Beverage("Hot Chocolate", 95,
                        "B-02", "S");

        Meal beefTapa =
                new Meal("Beef Tapa", 106,
                        "M-02", false, 2);

        Order order1 =
                new Order("1001", customer1);

        order1.addItem(latte);
        order1.addItem(ensaymada);
        order1.addItem(chicken);

        order1.printReceipt();

        Order order2 =
                new Order("1002", customer2);

        order2.addItem(chocolate);
        order2.addItem(beefTapa);

        order2.printReceipt(20);
    }
}
